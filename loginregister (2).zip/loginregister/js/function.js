$(document).ready(function() {
  $("#registerForm").on("submit", function (e) {
    e.preventDefault();
    var data = $("#registerForm").serialize();
    $.ajax({
      type: "POST",
      url: "functions.php",
      data: data,
      success: function (data) {
        console.log(data);
        if (data === "Registered Successfully") {
          $("#registerForm")[0].reset();
        } else {
          console.log(data);
        }
      }
    });  
  });
});

$(document).ready(function() {
  $("#loginForm").on("submit", function (e) {
    e.preventDefault();
    var data = $("#loginForm").serialize();
    $.ajax({
      type: "POST",
      url: "loginfunction.php",
      data: data,
      success: function (data) {
        if (data === "Login Successful") {
          $("#loginMessage").html("Login Successful").css("color", "green");
        } else {
          $("#loginMessage").html("Login Failed").css("color", "red");
        }
      }
    });  
  });
});
