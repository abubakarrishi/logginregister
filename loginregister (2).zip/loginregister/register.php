<?php include 'functions.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
    <script src="sweetalert2.all.min.js"></script>
    <title>Document</title>
</head>
<body>
<h2>Register</h2>
<div id="success-message" style="display: none;"></div>
    <form id="registerForm" method="post" action="">
        <label for="f_name">First Name:</label>
        <input type="text" id="f_name" name="f_name" class="clear">
        <br><br>
        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" class="clear">
        <br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" class="clear">
        <br><br>
        <label for="gender">Gender:</label>
        <input type="radio" name="gender"
        <?php if (isset($gender) && $gender=="female") echo "checked";?>
        value="female">Female
        <input type="radio" name="gender"
        <?php if (isset($gender) && $gender=="male") echo "checked";?>
        value="male">Male 
        <br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" class="clear">
        <br><br>
        <label for="c_password">Confirm Password:</label>
        <input type="password" id="c_password" name="c_password" class="clear">
        <br><br>
        <button type="submit" id="submit">Register</button>
    </form>
    <script src="js/function.js"></script>
</body>
</html>