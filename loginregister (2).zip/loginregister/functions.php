<?php
include 'conn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $f_name = sanitize_input($_POST['f_name']);
  $last_name = sanitize_input($_POST['last_name']);
  $email = sanitize_input($_POST['email']);
  $gender = sanitize_input($_POST['gender']);
  $password = $_POST['password'];
  $c_password = $_POST['c_password'];

  $required = [$f_name, $last_name, $email, $gender, $password, $c_password];
  if (in_array("", array_filter($required))) {
    echo "All fields are required.";
    return;
  }

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo "Invalid email format.";
      return;
  }

  if ($password !== $c_password) {
      echo "Passwords do not match.";
      return;
  }

  $password = password_hash($password, PASSWORD_DEFAULT);

  $insert_query = "INSERT INTO `login` (`f_name`, `last_name`, `email`, `gender`, `password`) VALUES ('$f_name', '$last_name', '$email', '$gender', '$password')";
  $result = mysqli_query($conn, $insert_query);
  if ($result == true) {
      echo "Registered Successfully";
  } else {
      echo "Error inserting record: " . mysqli_error($conn);
  }
}

function sanitize_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}








