<?php
session_start();
ob_start();
?>

<?

include 'conn.php';
if (isset($_POST['email']) && isset($_POST['password'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Connect to the database and select the user with the given email
  $email_search = "SELECT * FROM login WHERE email = '$email'";
    $result = mysqli_query($conn, $email_search);
    $email_count = mysqli_num_rows($result);
  // Check if the email exists in the database
 if ($email_count) {
    $email_pass = mysqli_fetch_assoc($result);
    $db_pass  = $email_pass['password'];
    $_SESSION['name'] = $email_pass['name'];
    $db_decode = password_verify($password, $db_pass);
    echo("Login Successful");
 }else{
    echo("Login Failed");
 }


  
}
?>