$(document).ready(function() {
  $("#registerForm").on("submit", function (e) {
    e.preventDefault();
    var data = $("#registerForm").serialize();
    $.ajax({
      type: "POST",
      url: "functions.php",
      data: data,
      success: function (response) {
        var data= JSON.parse(response);
        if (data.already) {
          $("#errorMessage").html("Email is already Taken").css("color", "red");
        }else if(data.password){
          $("#errorMessage").html("Password does not match").css("color", "red");
        }else{
          window.location.href = 'http://localhost/phppro/login.php';
          $("#errorMessage").html("Registered Successfully!").css("color", "green");
        }
      }
    });  
  });
});



$(document).ready(function() {
  $("#loginForm").on("submit", function () {
    var data = $("#loginForm").serialize();
    $.ajax({
      type: "POST",
      url: "loginfunction.php",
      data: data,
      success: function (data) {
        if (data === "Login Successful") {
          window.location.href = 'http://localhost/phppro/welcome.php';
          $("#loginMessage").html("Login Successful").css("color", "green");
        } else {
          $("#loginMessage").html("Login Failed").css("color", "red");
        }
      }
    });  
  });
});
