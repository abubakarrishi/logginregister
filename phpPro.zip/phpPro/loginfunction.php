<?php
session_start();
ob_start();
include 'conn.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = ($_POST['email']);
    $password = $_POST['password'];

    $email_search = "SELECT * FROM login WHERE email = '$email'";
    $result = mysqli_query($conn, $email_search);
    if (!$result) {
      die("Query Failed: " . mysqli_error($conn));
    }
    $email_count = mysqli_num_rows($result);
    if ($email_count) {
      $email_pass = mysqli_fetch_assoc($result);
      $db_pass  = $email_pass['password'];
      $_SESSION['id'] = $email_pass['id'];
      if (password_verify($password, $db_pass)) {
        echo("Login Successful");
      } else {
        echo("Login Failed");
      }
    } else {
      echo("Login Failed");
    }
  }
}
?>
